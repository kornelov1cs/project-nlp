For Linux users: 

If you double click the "pcpatr" program file, a terminal window with 
PC-PATR (version 1.4.6) should open.

If that doesn't work, try the following steps:

* open a terminal window yourself
* in the terminal window, navigate to the folder with "pcpatr" (for example "cd Downloads")
* type the commando "pcpatr" in the terminal window

If that still doesn't work, check that the file is executable (with "chmod +x pcpatr") or
contact Lorenzo Gatti (l.gatti@utwente.nl)

